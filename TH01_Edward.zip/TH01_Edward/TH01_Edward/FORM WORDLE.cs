﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01_Edward
{
    public partial class FORM_WORDLE : Form
    {
        public List<string> wordsbaru;
        string wordleRnd;
        public FORM_WORDLE()
        {
            InitializeComponent();
        }
        
        public void WordleKu(char a)
        {
            for(int i = 0; i < 5; i++)
            {
                if(a == wordleRnd[i])
                {
                    if(i == 0)
                    {
                        lb_word1.Text = a.ToString().ToUpper();
                    }
                    if (i == 1)
                    {
                        lb_word2.Text = a.ToString().ToUpper();
                    }
                    if (i == 2)
                    {
                        lb_word3.Text = a.ToString().ToUpper();
                    }
                    if (i == 3)
                    {
                        lb_word4.Text = a.ToString().ToUpper();
                    }
                    if (i == 4)
                    {
                        lb_word5.Text = a.ToString().ToUpper();
                    }
                }
            }
            MenangTidak();
        }
        private void MenangTidak()
        {
            string gabung = lb_word1.Text + lb_word2.Text + lb_word3.Text + lb_word4.Text + lb_word5.Text;
            if(gabung == wordleRnd.ToUpper())
            {
                MessageBox.Show("WUISH MENANG REK");
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lb_word1_Click(object sender, EventArgs e)
        {

        }
        private void FORM_WORDLE_Load(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int rndWord = rnd.Next(wordsbaru.Count);
            wordleRnd = wordsbaru[rndWord];

        }
        private void btn_Q_Click(object sender, EventArgs e)
        {
            WordleKu('q');
        }

       
        private void btn_W_Click(object sender, EventArgs e)
        {
            WordleKu('w');

        }
        private void btn_E_Click(object sender, EventArgs e)
        {
            WordleKu('e');
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            WordleKu('r');

        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            WordleKu('t');

        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            WordleKu('y');
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            WordleKu('u');
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            WordleKu('i');
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            WordleKu('o');
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            WordleKu('p');
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            WordleKu('a');
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            WordleKu('s');
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            WordleKu('d');
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            WordleKu('f');
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            WordleKu('g');
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            WordleKu('h');
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            WordleKu('j');
        }


        private void btn_K_Click(object sender, EventArgs e)
        {
            WordleKu('k');
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            WordleKu('l');
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            WordleKu('z');
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            WordleKu('x');
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            WordleKu('c');
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            WordleKu('v');
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            WordleKu('b');
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            WordleKu('n');
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            WordleKu('m');
        }
    }
}
