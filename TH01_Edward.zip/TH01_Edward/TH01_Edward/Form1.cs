﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01_Edward
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            List<string> words = new List<string>();
            int counter = 0;
            if (tb_word1.Text.Length.ToString() != "" && tb_word2.Text.Length.ToString() != "" && tb_word3.Text.Length.ToString() != "" && tb_word4.Text.Length.ToString() != "" && tb_word5.Text.Length.ToString() != "")
            {
                if (tb_word1.Text.Length == 5 && tb_word2.Text.Length == 5 && tb_word3.Text.Length == 5 && tb_word4.Text.Length == 5 && tb_word5.Text.Length == 5)
                {
                    words.Add(tb_word1.Text);
                    words.Add(tb_word2.Text);
                    words.Add(tb_word3.Text);
                    words.Add(tb_word4.Text);
                    words.Add(tb_word5.Text);

                    foreach (string a in words)
                    {
                        foreach (string b in words)
                        {
                            if (a == b)
                            {
                                counter++;
                            }
                        }
                    }
                    if (counter == 5)
                    {
                        FORM_WORDLE FormWordle = new FORM_WORDLE();
                        FormWordle.wordsbaru = words;
                        FormWordle.Show();

                    }
                    else
                    {
                        MessageBox.Show("Huruf Ada yang sama");
                    }
                }
                else
                {
                    MessageBox.Show("5 Huruf Bro");
                }
            }
            else
            {
                MessageBox.Show("Isi semua hey");

            }

        }
    }
}
